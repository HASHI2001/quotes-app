import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(QuoteApp());
}

class Quote {
  final String text;
  final String author;
  final String category;
  final String details;

  Quote({
    required this.text,
    required this.author,
    required this.category,
    required this.details,
  });
}

class QuoteApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Famous Quotes',
      theme: ThemeData(primarySwatch: Colors.brown),
      home: QuoteScreen(),
    );
  }
}

class QuoteScreen extends StatefulWidget {
  @override
  _QuoteScreenState createState() => _QuoteScreenState();
}

class _QuoteScreenState extends State<QuoteScreen> {
  final List<String> categories = [
    "Motivational",
    "Finance",
    "Romance",
    "History"
  ];
  String selectedCategory = "Motivational";

  final List<Quote> quotes = [
    Quote(
      text: "The only way to do great work is to love what you do.",
      author: "Steve Jobs",
      category: "Motivational",
      details: "Steve Jobs was an American business magnate and investor.",
    ),
    Quote(
      text: "An investment in knowledge pays the best interest.",
      author: "Benjamin Franklin",
      category: "Finance",
      details: "Benjamin Franklin was one of the Founding Fathers of the USA.",
    ),
    Quote(
      text: "The best thing to hold onto in life is each other.",
      author: "Audrey Hepburn",
      category: "Romance",
      details: "Audrey Hepburn was a British actress and humanitarian.",
    ),
    Quote(
      text: "Those who cannot remember the past are condemned to repeat it.",
      author: "George Santayana",
      category: "History",
      details:
          "George Santayana was a Spanish-American philosopher and writer.",
    ),
  ];

  Quote? currentQuote;

  @override
  void initState() {
    super.initState();
    fetchRandomQuote();
  }

  void fetchRandomQuote() {
    final filteredQuotes =
        quotes.where((q) => q.category == selectedCategory).toList();
    setState(() {
      currentQuote = filteredQuotes[Random().nextInt(filteredQuotes.length)];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Random Famous Quote')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            DropdownButton<String>(
              value: selectedCategory,
              items: categories.map((String category) {
                return DropdownMenuItem<String>(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedCategory = newValue!;
                  fetchRandomQuote();
                });
              },
            ),
            SizedBox(height: 20),
            currentQuote != null
                ? Column(
                    children: [
                      Text(
                        '"${currentQuote!.text}"',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 18, fontStyle: FontStyle.italic),
                      ),
                      SizedBox(height: 10),
                      Text('- ${currentQuote!.author}',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: fetchRandomQuote,
                        child: Text('New Quote'),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  DetailScreen(quote: currentQuote!),
                            ),
                          );
                        },
                        child: Text('View Details'),
                      ),
                    ],
                  )
                : CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  final Quote quote;

  DetailScreen({required this.quote});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(quote.author)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(quote.text,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic)),
            SizedBox(height: 10),
            Text('- ${quote.author}',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Text(quote.details,
                textAlign: TextAlign.center, style: TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}
